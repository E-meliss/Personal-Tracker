<template>
  <div class="app-shell">
    <router-view />
  </div>
</template>

<style scoped>
.app-shell { min-height: 100vh; }
</style>
